# DNA datasets

## 3782

Real dataset from (Grimm 2009).


## References

* Stamatakis A., G&ouml;ker M., Grimm GW. (2009)
**Maximum Likelihood Analyses of 3,490 rbcL Sequences: Scalability of Comprehensive Inference versus Group-Specific Taxon Sampling.**
*Evolutionary Bioinformatics*, 2010(6): 73-90.
doi:[10.4137/EBO.S4528](http://dx.doi.org/10.4137/EBO.S4528)
